// alert("hello world");

///////////////      Date Methods //////////////////////

//////////    Question no 1 ////////////////////

// var now = new Date();

// document.write(now);

///////////////    Question no 2 ////////////

// var  months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
// var now = new Date();
// var monthName=months[now.getMonth()]
// alert("Current Month: "+ monthName);


///////////    Question no 3 /////////////////////////////////


// var days = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]

// var now = new Date();

// var dayName = days[now.getDay()]

// alert( "Today is : " + dayName.slice(0,3));


/////////////    Question no 4 ///////////////

// var date = new Date();
// switch(date.getDay()){
//     case 0: alert("Its Funday!"); break;
//     case 6: alert("Its Funday !"); break;
//     default: alert("any other week day");
// }



//////////    Question no   6  /////////////////

var today = new Date();
var pastDate = new Date(" 1 Jan  1970");

var msToday = today.getTime();
var mspastDate = pastDate.getTime();

var msDiff = msToday - mspastDate;

var diff = msDiff/ (1000*60);
document.write("Current Date : " + today+ "</br>"+ "Elapsed Miliseconds Since Jan 1 1970 : " + msDiff+"</br>"+
"Elapsed Minutes Since Jan 1 1970 : " + diff);


////////////   Question no 7 ///////////////////////



// var date = new Date();
// switch(date.getTime()){
//     case 12: alert("Its Funday!"); break;
//     case 6: alert("Its Funday !"); break;
//     default: alert("any other week day");
// }



